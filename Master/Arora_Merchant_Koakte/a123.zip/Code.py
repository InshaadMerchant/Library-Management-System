from tkinter import *
import sqlite3

root = Tk()
root.title('Library Mangement System')
root.geometry("500x500")
#address_book_connect = sqlite3.connect(os.path.abspath('lms.db'))
#address_book_cur = address_book_connect.cursor()



#query-1
def query1():
    query1_pop = Toplevel(root)
    query1_pop.geometry("500x500")
    query1_pop.title("query1")

    info = Label(query1_pop, text = " Please enter your card_no,branch_id,book_id by refering the name from the list below\n the list: book_id, Title, per_Book_copies, Branch_id\n")
    info.grid(row = 0, column = 1, padx = 20)
    bookid = Entry(query1_pop, width = 30)
    bookid.grid(row = 1, column = 1, padx = 20)
    bookid_label = Label(query1_pop, text = 'Bookid: ')
    bookid_label.grid(row =1, column = 0)

    branchid = Entry(query1_pop, width = 30)
    branchid.grid(row = 2, column = 1, padx = 20)
    branchid_label = Label(query1_pop, text = 'branchid: ')
    branchid_label.grid(row =2, column = 0)

    cardno = Entry(query1_pop, width = 30)
    cardno.grid(row = 3, column = 1, padx = 20)
    cardno_label = Label(query1_pop, text = 'card_no: ')
    cardno_label.grid(row =3, column = 0)

    datedue = Entry(query1_pop, width = 30)
    datedue.grid(row = 4, column = 1, padx = 20)
    datedue_label = Label(query1_pop, text = 'datedue: ')
    datedue_label.grid(row =4, column = 0)

    dateout = Entry(query1_pop, width = 30) 
    dateout.grid(row = 5, column = 1, padx = 20)
    dateout_label = Label(query1_pop, text = 'dateout: ')
    dateout_label.grid(row =5, column = 0)

    iq_conn = sqlite3.connect('lms.db')
    iq_cur = iq_conn.cursor()


    iq_cur.execute("SELECT B.Book_id, B.Title, COUNT(no_of_copies), BC.Branch_Id FROM BOOK_COPIES as BC, BOOK as B WHERE B.Book_id = BC.Book_id GROUP BY B.Book_id,BC.Branch_Id")
    output_records = iq_cur.fetchall()
    print_record = ''
    for output_record in output_records:
        print_record += ( "{},{},{},{} \n".format(output_record[0],output_record[1],output_record[2],output_record[3]))
    iq_label = Label(query1_pop, text = print_record)
    iq_label.grid(row = 8, column = 0, columnspan = 2)
    #commit changes
    iq_conn.commit()
    #close the DB connection
    iq_cur.close()
    iq_conn.close()

    submit_btn = Button(query1_pop, text ='CheckOut ', command=lambda: submit1(bookid.get(),
                                                                        branchid.get(),
                                                                        cardno.get(),
                                                                        dateout.get(),
                                                                        datedue.get(),query1_pop))
    submit_btn.grid(row = 6, column =0, columnspan = 2, pady = 10, padx = 10, ipadx =140)
    
def submit1(bi,bri,cn,do,dd,query1_pop):
    submit_conn = sqlite3.connect('lms.db')
    submit_cur = submit_conn.cursor()
    try:
        submit_cur.execute("INSERT INTO BOOK_LOANS (Book_id, Branch_id, Card_No, Date_Out, Due_Date) VALUES (:Book_id,:Branch_id,:Card_No,:Date_Out,:Due_Date) ",
            {
            'Book_id': bi,
            'Branch_id': bri,
            'Card_No': cn,
            'Date_Out': do,
            'Due_Date': dd,
            })
    except sqlite3.Error as e:
        print('Error Insert failed:',e)
    submit_cur.execute("UPDATE BOOK_COPIES SET no_of_copies = no_of_copies - 1 WHERE Branch_Id = 'bri' AND Book_id = 'bi'")
    submit_cur.execute("SELECT no_of_copies FROM BOOK_COPIES WHERE  Branch_Id = 'bri' AND Book_id = 'bi' ")
    output_records = submit_cur.fetchone()
    print_record = "The updated no_of_copies at the selected branch is " + str(output_records)
    label = Label(query1_pop, text = print_record)
    label.grid(row = 7, column = 0, columnspan = 2)
    submit_conn.commit()
    submit_conn.close()








#query2
def q2():
    #q2_conn = sqlite3.connect('lms.db');
    #q2_cursor = q2_conn.cursor();
    q2_pop = Toplevel(root)
    q2_pop.geometry("900x600")
    q2_pop.title("Query #2")

    q2_purposeText = Label(q2_pop,text='Add information about borrower in the given fields:\n')
    q2_purposeText2 = Label(q2_pop,text='Enter full name in "Name" Field and Address in "Address" Field\n and phone number in "PhoneNum" Field in the format XXX-XXX-XXXX \n')
    q2_purposeText.grid(row =0, column =0)
    q2_purposeText2.grid(row =1, column =0)
    
    name = Entry(q2_pop, width = 80)
    name.grid(row =2, column =1)

    addr = Entry(q2_pop, width = 80)
    addr.grid(row =3, column =1)

    phone = Entry(q2_pop, width = 20)
    phone.grid(row =4, column =1)

    in_name_label = Label(q2_pop, text = 'Name')
    in_name_label.grid(row =2, column =0)
    in_addr_label = Label(q2_pop, text = 'Address')
    in_addr_label.grid(row =3, column =0)
    in_phone_label = Label(q2_pop, text = 'PhoneNum')
    in_phone_label.grid(row =4, column =0)

    
    submit_btn = Button(q2_pop, text = 'Add Borrower',
                            command = lambda :q2_submit(name,addr,phone,q2_pop))
    submit_btn.grid(row =5, column = 0, columnspan =2)
   
def q2_submit(name, addr, phone, q2_pop):
    q2_conn = sqlite3.connect('lms.db')
    q2_cur = q2_conn.cursor()
    q2_cur.execute("INSERT INTO BORROWER(Name, address, phone) VALUES (:Name, :address, :phone)",
                   {
                       'Name': name.get(),
                       'address': addr.get(),
                       'phone': phone.get()
                   })
    
    q2_cur.execute("SELECT Card_no FROM BORROWER WHERE Name = ? AND address = ? AND phone = ?",(name.get(),addr.get(),phone.get()))
    output = q2_cur.fetchone()
    print_record = ''
    print(output[0])
    print_record += str(output[0])
    print_record = "Card Number assigned: " + print_record +"\n"
    output_label = Label(q2_pop, text=print_record)
    output_label.grid(row=10,column=0, columnspan=2)

    q2_conn.commit()
    q2_conn.close()






#query-3
def q3():
    def submit():
        book_title_t = book_title.get()
        author_name_t = author_name.get()
        publisher_name_t = publisher_name.get()

        submit_conn = sqlite3.connect('lms.db')
        submit_cur = submit_conn.cursor()

       
        submit_cur.execute('INSERT INTO BOOK (Title, Publisher_Name) VALUES (?, ?)', (book_title_t, publisher_name_t))
        book_id = submit_cur.lastrowid

        
        submit_cur.execute('INSERT INTO BOOK_AUTHORS (Book_Id, Author_Name) VALUES (?, ?)', (book_id, author_name_t))


        for i in range(1, 6):
            submit_cur.execute('INSERT INTO BOOK_COPIES (Book_Id, Branch_Id, no_of_copies) VALUES (?, ?, ?)',
                               (book_id, i, 5))



        submit_conn.commit()
        submit_conn.close()

    iq = sqlite3.connect('lms.db')
    iq_cur = iq.cursor()

    root = Tk()
    root.title('Add Book')
    root.geometry("500x500")



    book_title = Entry(root, width=30)
    book_title.grid(row=0, column=1, padx=20)

    author_name = Entry(root, width=30)
    author_name.grid(row=1, column=1)

    publisher_name = Entry(root, width=30)
    publisher_name.grid(row=2, column=1)




    book_title_label = Label(root, text='Book Title: ')
    book_title_label.grid(row=0, column=0, padx=20)

    author_name_label = Label(root, text='Author Name: ')
    author_name_label.grid(row=1, column=0)

    publisher_name_label = Label(root, text='Publisher Name: ')
    publisher_name_label.grid(row=2, column=0)

  

    submit_button = Button(root, text='Add', command = submit)
    submit_button.grid(row=6, column=0, columnspan=2, pady=10, padx=100)

    iq.commit()
    iq.close()








#query-4
def q4():
    q4_pop = Toplevel(root);
    q4_pop.geometry("900x600");
    q4_pop.title("Query #4");

    q4_purposeText = Label(q4_pop,text='From the book list below enter a book title in the text field below:\n')
    #q4_purposeText2 = Label(q4_pop,text='Enter full name in "Name" Field and Address in "Address" Field\n and phone number in "PhoneNum" Field in the format XXX-XXX-XXXX \n')
    q4_purposeText.grid(row =0, column =0)
    #q4_purposeText2.grid(row =1, column =0)
    
    q4_conn = sqlite3.connect('lms.db')
    q4_cur = q4_conn.cursor()
    q4_cur.execute("SELECT Book_id, Title FROM BOOK")

    output = q4_cur.fetchall()
    print_rec = ''
    
    for outp in output:
        print_rec += str(str(outp[0]) + " " + outp[1]+"\n")

    out_label = Label(q4_pop, text = print_rec)
    out_label.grid(row =2, column=0, columnspan =2)

    q4_conn.commit()
    q4_conn.close()  
  
    title = Entry(q4_pop, width = 80)
    title.grid(row =3, column =1)

    title_label = Label(q4_pop, text = 'Enter the book title: ')
    title_label.grid(row =3, column = 0)

    submit_btn = Button(q4_pop, text = 'Enter Title',
            command = lambda :q4_submit(title, q4_pop))
    submit_btn.grid(row =4, column = 0, columnspan =2)

def q4_submit(title, q4_pop):
    q4_conn = sqlite3.connect('lms.db')
    q4_cur = q4_conn.cursor()
    #t = str("'"+str(title.get())+"'")
    t = title.get()
    #print(t)
    #print(len(t))
    q4_cur.execute("SELECT Branch_Name, COUNT(*) FROM BOOK_LOANS as BL,LIBRARY_BRANCH as LB, BOOK as B WHERE BL.Branch_id = LB.Branch_id AND BL.Book_id = B.Book_id AND Title like ? GROUP BY Branch_Name",(t,))
    output = q4_cur.fetchall()
    print_rec = 'Branch Name               Number of Copies\n\n'
    #output = str(output)
    #print(output)
    for outp in output:
        print_rec += str(str(outp[0]) + "                " + str(outp[1])+"\n")

    #print(print_rec)
    output_label = Label(q4_pop, text=print_rec)
    output_label.grid(row=5,column=0, columnspan=2)
    q4_conn.commit()
    q4_conn.close()








#query-6b
def q6b():
    q6b_pop = Toplevel(root)
    q6b_pop.geometry("1000x600")
    q6b_pop.title("Query #6b")

    q6b_purposeText = Label(q6b_pop,text='Enter Book_id or/and Book Title(partial or full) or Nothing at all. Click Button "Search".\n')
    #q4_purposeText2 = Label(q4_pop,text='Enter full name in "Name" Field and Address in "Address" Field\n and phone number in "PhoneNum" Field in the format XXX-XXX-XXXX \n')
    q6b_purposeText.grid(row =0, column =0)
    #q4_purposeText2.grid(row =1, column =0)
    
    Bookid = Entry(q6b_pop, width = 10)
    Bookid.grid(row =2, column =1)

    Bookid_label = Label(q6b_pop, text = 'Enter Book ID:')
    Bookid_label.grid(row =2, column = 0)

    BookTitle = Entry(q6b_pop, width = 80)
    BookTitle.grid(row =3, column =1)

    BookTitle_label = Label(q6b_pop, text = 'Enter Book Title(full or partial):')
    BookTitle_label.grid(row =3, column = 0)

    submit_btn = Button(q6b_pop, text = 'Search',
            command = lambda :q6b_submit(Bookid, BookTitle,q6b_pop))
    submit_btn.grid(row =4, column = 1, columnspan =2, pady=10)
    #q4_conn = sqlite3.connect('lms.db')
    #q4_cur = q4_conn.cursor()
    #q4_cur.execute("SELECT Book_id, Title FROM BOOK")

def q6b_submit(Bookid, BookTitle, q6b_pop):
    q6b_conn = sqlite3.connect('lms.db')
    q6b_cur = q6b_conn.cursor()

    id = Bookid.get()
    title = BookTitle.get()

    if((id != "") and (title != "")): 
        q6b_cur.execute("SELECT B.Book_id,vB.Book_Title,vB.Branch_ID,vB.LateFeeBalance FROM vBookLoanInfo as vB,BOOK as B WHERE vB.Book_Title = B.Title AND Book_id = ? AND vB.Book_Title like '%'||?||'%'",(id,title,))

    if((id == "") and (title != "")):
        q6b_cur.execute("SELECT B.Book_id,vB.Book_Title,vB.Branch_ID,vB.LateFeeBalance FROM vBookLoanInfo as vB,BOOK as B WHERE vB.Book_Title = B.Title AND vB.Book_Title like '%'||?||'%'",(title,))

    if((id != "") and (title == "")):
        q6b_cur.execute("SELECT B.Book_id,vB.Book_Title,vB.Branch_ID,vB.LateFeeBalance FROM vBookLoanInfo as vB,BOOK as B WHERE vB.Book_Title = B.Title AND Book_id = ?",(id,))


    if((id == "") and (title == "")):
        q6b_cur.execute("SELECT B.Book_id,vB.Book_Title,vB.Branch_ID,vB.LateFeeBalance FROM vBookLoanInfo as vB,BOOK as B WHERE vB.Book_Title = B.Title ORDER BY LateFeeBalance")



    output = q6b_cur.fetchall()
    print_rec = 'The format for output is (Book ID, Book Title, Branch ID, Late Fee Balance): \n\n'
    
    for outp in output:
        print_rec += str(str(outp[0]) + "   ,   "+ str(outp[1])  + "   ,   "+ str(outp[2]) + "   ,   " + str("$"+str(outp[3])+".00")+"\n")

    

   
    output_label =Label(q6b_pop,text=print_rec)
    output_label.grid(row=5,column=0, columnspan=2)

    #output_label.grid_forget()
    q6b_conn.commit()
    q6b_conn.close()  



#query-5
def query5():
    query5_pop = Toplevel(root)
    query5_pop.geometry("500x500")
    query5_pop.title("query5")

    iq_conn = sqlite3.connect('lms.db')
    iq_cur = iq_conn.cursor()

    info = Label(query5_pop, text = " Please enter the range of the due date for the retrieve of the late books \n the list: book_id, Branch_id, card_no, date_out, Due_Date, Returned_date, num_days_late\n")
    info.grid(row = 0, column = 1, padx = 20)
    start = Entry(query5_pop, width = 30)
    start.grid(row = 1, column = 1, padx = 20)
    start_label = Label(query5_pop, text = 'first due date: ')
    start_label.grid(row =1, column = 0)

    finish = Entry(query5_pop, width = 30)
    finish.grid(row = 2, column = 1, padx = 20)
    finish_label = Label(query5_pop, text = 'last due date: ')
    finish_label.grid(row =2, column = 0)

    submit_btn = Button(query5_pop, text ='Find', command=lambda: submit5(start.get(), finish.get() ,query5_pop))
    submit_btn.grid(row = 3, column =0, columnspan = 2, pady = 10, padx = 10, ipadx =140)
    #commit changes
    iq_conn.commit()
    #close the DB connection
    iq_cur.close()
    iq_conn.close()

def submit5(st,fh,query5_pop):
    submit_conn = sqlite3.connect('lms.db')
    submit_cur = submit_conn.cursor()
    try:
        submit_cur.execute(" SELECT Book_id, Branch_id, Card_No, Date_Out, Due_Date, Returned_date, CAST(JULIANDAY(Returned_date) AS INTEGER) - CAST(JULIANDAY(Due_Date)AS INTEGER) AS num_days_late FROM BOOK_LOANS WHERE Late = '1' AND (Due_Date < ? AND   Due_Date > ?) ",
        (fh, st,))
    except sqlite3.Error as e:
        print('Error Select failed:',e)
    output_records = submit_cur.fetchall()
    print_record = ''
    for output_record in output_records:
        print_record += ( "{},{},{},{},{},{},{} \n".format(output_record[0],output_record[1],output_record[2],output_record[3],output_record[4],output_record[5],output_record[6]))
    iq_label = Label(query5_pop, text = print_record)
    iq_label.grid(row = 4, column = 0, columnspan = 2)






#query-6a
def query6():
    query6_pop = Toplevel(root)
    query6_pop.geometry("500x500")
    query6_pop.title("query6a")

    iq_conn = sqlite3.connect('lms.db')
    iq_cur = iq_conn.cursor()

    info = Label(query6_pop, text = " Search For Borrrower's information by entering ID or name nor None \n the Output will be in the following order: Card_no,Name,LateFeeBalance \n")
    info.grid(row = 0, column = 1, padx = 20)
    borrower = Entry(query6_pop, width = 30)
    borrower.grid(row = 1, column = 1, padx = 20)
    borrower_label = Label(query6_pop, text = 'BorrowerID: ')
    borrower_label.grid(row =1, column = 0)

    name = Entry(query6_pop, width = 30)
    name.grid(row = 2, column = 1, padx = 20)
    name_label = Label(query6_pop, text = 'Name: ')
    name_label.grid(row =2, column = 0)

    submit_btn = Button(query6_pop, text ='Search ', command=lambda: submit6(borrower.get(), name.get() ,query6_pop))
    submit_btn.grid(row = 3, column =0, columnspan = 2, pady = 10, padx = 10, ipadx =140)
    #commit changes
    iq_conn.commit()
    #close the DB connection
    iq_cur.close()
    iq_conn.close()

def submit6(id,nme,query6_pop):
    submit_conn = sqlite3.connect('lms.db')
    submit_cur = submit_conn.cursor()
    try:
        if(id == "" and nme != ""):
            submit_cur.execute("SELECT DISTINCT Card_no,Name FROM BORROWER,LateFeeBalance FROM vBookLoanInfo WHERE Name LIKE '%'||?||'%'",
        (nme,))
        elif(nme == "" and id != ""):
            submit_cur.execute("SELECT DISTINCT Card_no,Name,LateFeeBalance FROM vBookLoanInfo WHERE Card_no = ?",
        (id,))
        elif(nme != "" and id != ""):
            submit_cur.execute("SELECT DISTINCT Card_no,Name,LateFeeBalance FROM vBookLoanInfo WHERE Card_no = ? AND Name LIKE '%'||?||'%'",
        (id,nme,))
        else:
            submit_cur.execute("SELECT DISTINCT Card_no,Name,LateFeeBalance FROM vBookLoanInfo ORDER BY LateFeeBalance DESC")   
    except sqlite3.Error as e:
        print('Error Select failed:',e)
    output_records = submit_cur.fetchall()
    print_record = ''
    for output_record in output_records:
        print_record += ( "{},{},${}.00 \n".format(output_record[0],output_record[1],output_record[2]))
    iq_label = Label(query6_pop, text = print_record)
    iq_label.grid(row = 4, column = 0, columnspan = 2)
    


#Buttons on the main window
query1_btn = Button(root, text ='Query-1', command = query1 )
query1_btn.grid(row = 0, column =0, columnspan = 2, pady = 10, padx = 10, ipadx =140)

q2_btn = Button(root, text='Query 2',command = q2)
q2_btn.grid(row =1, column=0, columnspan=2, pady=10, padx=10, ipadx=140)

q3_button = Button(root, text = 'Query 3', command = q3)
q3_button.grid(row = 2, column = 0, columnspan = 2, pady= 10, padx = 10, ipadx = 100)

q4_btn = Button(root, text='Query 4',command = q4)
q4_btn.grid(row =3, column=0, columnspan=2, pady=10, padx=10, ipadx=140)


query5_btn = Button(root, text ='Query-5', command=query5)
query5_btn.grid(row = 4, column =0, columnspan = 2, pady = 10, padx = 10, ipadx =140)

query6_btn = Button(root, text ='Query-6a', command=query6)
query6_btn.grid(row = 5, column =0, columnspan = 2, pady = 10, padx = 10, ipadx =140)


q6b_btn = Button(root, text='Query 6b',command = q6b)
q6b_btn.grid(row =6, column=0, columnspan=2, pady=10, padx=10, ipadx=140)

root.mainloop()