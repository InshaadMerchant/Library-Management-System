INSERT INTO BOOK(Title, Publisher_name)
VALUES('Harry Potter and the Sorcerer"s Stone','Oxford Publishing');

INSERT INTO BOOK_AUTHORS(Author_Name)
VALUES('J.K.Rowling');