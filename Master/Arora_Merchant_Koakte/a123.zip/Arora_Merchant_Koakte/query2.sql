UPDATE BORROWER
SET Phone = '837-721-8965'
WHERE Name like 'Araohat Kokate';