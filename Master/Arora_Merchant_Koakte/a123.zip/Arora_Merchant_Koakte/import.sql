
.mode csv
.import --skip 1 Book.csv BOOK
.import --skip 1 Book_Authors.csv BOOK_AUTHORS
.import --skip 1 Book_Copies.csv BOOK_COPIES
.import --skip 1 Book_Loans.csv BOOK_LOANS
.import --skip 1 Borrower.csv BORROWER
.import --skip 1 Library_Branch.csv LIBRARY_BRANCH
.import --skip 1 Publisher.csv PUBLISHER


