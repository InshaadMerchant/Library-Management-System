INSERT INTO BORROWER(Name, Address, Phone)
VALUES('Araohat Kokate','587 Spaniolo Dr, Arlington TX, 76010','682-340-0275');

