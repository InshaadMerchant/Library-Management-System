INSERT INTO LIBRARY_BRANCH(Branch_name, Address)
VALUES('North Branch','456 NW, Irving, TX 76100');

INSERT INTO LIBRARY_BRANCH(Branch_name, Address)
VALUES('UTA Branch','123 Cooper St, Arlington TX 76101');