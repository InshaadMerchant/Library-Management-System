.headers on
.mode column
SELECT * FROM BOOK_AUTHORS;
.headers off
SELECT 'No. of Entries in BOOK_AUTHORS:', COUNT(*) FROM BOOK_AUTHORS;
