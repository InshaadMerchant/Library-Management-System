.read createTables.sql
.read import.sql
.read query1.sql
.read query2.sql
.read query3.sql
.read query4a.sql
.read query4b.sql
.read query5.sql
.read query6.sql
.read query7.sql
.read query8.sql
.read query9.sql
.read query10.sql
.read part3.sql
.read part3q2.sql
.read part3q3.sql

