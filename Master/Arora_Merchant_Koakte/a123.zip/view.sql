.headers on
.mode column
SELECT * FROM BOOK ;


